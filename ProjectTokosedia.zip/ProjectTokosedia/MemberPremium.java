public class MemberPremium {
    double POTONGAN=0.1;
    String kodeVoucher="TOKOSEDIA25";
    Member m;
    public MemberPremium(String nama, String alamat){
        m = new Member(nama,alamat);

    }
    void topUp(long i){
        m.topUp(i);
    }
    void cekSaldo(){
        m.cekSaldo();
    }
    public void bayar(long byr, String kode){
        if(kode==kodeVoucher){
            long bayar=byr;
            bayar=(long) (byr-(byr*0.25));
            if(m.dompet.getSaldo()>bayar){
                System.out.println("Pembayaran sukes!");
                m.dompet.saldo=m.dompet.saldo-bayar;
            }else{
                System.out.println("Pembayaran gagal! Saldao Ando tidak cuku[!");
            }
        }else{
            System.out.println("Pembayaran gagal! Kode tidak valid atau voucher sudah kadaluarsa!");
        }


    }
    public void bayar(long byr){
        long bayar=byr;
        bayar=(long) (byr-(byr*0.1));
        if(m.dompet.getSaldo()>bayar){
            System.out.println("Pembayaran sukes!");
            m.dompet.saldo=m.dompet.saldo-bayar;
        }else{
            System.out.println("Pembayaran gagal! Saldao Ando tidak cuku[!");
        }
    }
}