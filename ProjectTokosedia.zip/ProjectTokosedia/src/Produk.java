public class Produk {
    String namaProduk;
    long harga;

    public Produk() {

    }

    public Produk(String namaProduk, long harga){
        this.namaProduk=namaProduk;
        this.harga=harga;

    }
    long getHarga(){
        return harga;
    }
    String getNamaProduk(){
        return namaProduk;
    }
}