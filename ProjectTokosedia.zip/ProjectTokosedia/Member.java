public class Member {
    String alamat;
    String nama;
    Dompet dompet =new Dompet();


    public Member(String nama,String alamat){
        this.nama=nama;
        this.alamat=alamat;
    }

    Member() {

    }

    public String getAlamat() {
        return alamat;
    }

    public String getNama() {
        return nama;
    }
    public void topUp(long topup){
        dompet.setSaldo(topup);
    }
    public void cekSaldo(){
        System.out.println("Nama Member: "+nama);
        System.out.println("Saldo Dompet Saat Ini: "+dompet.getSaldo());
    }
    public void bayar(long byr){
        if(dompet.getSaldo()>byr){
            System.out.println("Pembayaran sukses!");
            dompet.saldo=dompet.saldo-byr;
        }else{
            System.out.println("Pembayaran gagal! Saldo Anda tidak cukup!");
        }
    }
}