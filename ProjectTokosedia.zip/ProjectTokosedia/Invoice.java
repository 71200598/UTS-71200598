public class Invoice {
    int jumlah;
    long tagihan;
    Produk produk = new Produk();
    Member member = new Member();
    public Invoice() {
    }

    public void printInvoice(){
        System.out.println("Kepada: Yth. "+member.getNama());
        System.out.println("Di "+member.getAlamat());
        System.out.println(jumlah+"x "+produk.getNamaProduk()+" Rp "+produk.getHarga());
        System.out.println("-------> Total Tagihan: Rp "+tagihan);

    }

    public long getTagihan() {
        return tagihan;
    }

    public void buatInvoice(Produk p,int jml,Member m){
        jumlah=jml;
        produk=p;
        member=m;
        tagihan=produk.getHarga()*jumlah;
    }

    public void buatInvoice(Produk p,int jml,MemberPremium m){
        jumlah=jml;
        produk=p;
        member=m.m;
        tagihan=produk.getHarga()*jumlah;
    }


}