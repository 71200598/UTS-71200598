public class Dompet {
    long saldo;

    public Dompet() {
    }

    public long getSaldo() {
        return saldo;
    }

    public void setSaldo(long saldo) {
        if(saldo<=0){
            System.out.println("pembayaran gagal");

        }else{
            System.out.println("top up sukses");
            this.saldo = this.saldo+saldo;
        }}

}